"""
Unit tests for Pyolice
"""